package org.example;

public class CancelledState implements AppointmentState {

    @Override
    public void confirm(Appointment appointment) {
        System.out.println("Нельзя подтвердить отменённый приём.");
    }

    @Override
    public void cancel(Appointment appointment) {
        // уже отменён
    }

    @Override
    public void complete(Appointment appointment) {
        System.out.println("Нельзя завершить отменённый приём.");
    }

    @Override
    public String getName() {
        return "CANCELLED";
    }
}