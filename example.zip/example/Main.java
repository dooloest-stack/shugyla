package org.example;

import java.time.LocalTime;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        DatabaseInitializer.init();
        ClinicFacade facade = new ClinicFacade();
        seedDoctorsIfNeeded(facade);
        mainMenu(facade);
    }
    private static void mainMenu(ClinicFacade facade) {
        while (true) {
            System.out.println("\n=== Clinic Appointment System ===");
            System.out.println("1. Войти как пациент");
            System.out.println("2. Войти как доктор");
            System.out.println("0. Выход");
            System.out.print("Выберите пункт: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    patientMenu(facade);
                    break;
                case "2":
                    doctorMenu(facade);
                    break;
                case "0":
                    System.out.println("До свидания!");
                    return;
                default:
                    System.out.println("Неверный выбор, попробуйте ещё раз.");
            }
        }
    }

    // ==================== МЕНЮ ПАЦИЕНТА ====================

    private static void patientMenu(ClinicFacade facade) {
        System.out.println("\n=== Вход пациента ===");
        int patientId;
        while (true) {
            System.out.print("Если вы уже зарегистрированы, введите ваш patientId, иначе введите 0: ");
            patientId = readInt();

            if (patientId == 0) {
                System.out.print("Введите ваше имя: ");
                String name = scanner.nextLine();
                System.out.print("Введите телефон: ");
                String phone = scanner.nextLine();
                patientId = facade.registerPatient(name, phone);
                System.out.println("Вы зарегистрированы. Ваш patientId = " + patientId);
                break;
            }

            if (facade.patientExists(patientId)) {
                break;
            }

            System.out.println("Пациент с таким ID не найден. Попробуйте снова или введите 0 для регистрации.");
        }

        while (true) {
            System.out.println("\n=== Меню пациента ===");
            System.out.println("1. Записаться на приём");
            System.out.println("2. Посмотреть мои записи");
            System.out.println("3. Отменить запись");
            System.out.println("0. Назад");
            System.out.print("Ваш выбор: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    bookAppointmentAsPatient(facade, patientId);
                    break;
                case "2":
                    showAppointmentsForPatient(facade, patientId);
                    break;
                case "3":
                    cancelAppointmentAsPatient(facade, patientId);
                    break;
                case "0":
                    return;
                default:
                    System.out.println("Неверный выбор.");
            }
        }
    }

    private static void bookAppointmentAsPatient(ClinicFacade facade, int patientId) {
        System.out.println("=== Запись на приём ===");

        // 1. Выбор специализации и врача (как у тебя уже было)
        List<String> specs = facade.getAllSpecializations();
        if (specs.isEmpty()) {
            System.out.println("Нет врачей в системе.");
            return;
        }

        System.out.println("Доступные специализации:");
        for (int i = 0; i < specs.size(); i++) {
            System.out.println((i + 1) + ". " + specs.get(i));
        }
        System.out.print("Выберите специализацию: ");
        int specChoice = readInt();
        if (specChoice < 1 || specChoice > specs.size()) {
            System.out.println("Неверный выбор.");
            return;
        }
        String chosenSpec = specs.get(specChoice - 1);

        List<Doctor> doctors = facade.getDoctorsBySpecialization(chosenSpec);
        if (doctors.isEmpty()) {
            System.out.println("Врачей этой специализации нет.");
            return;
        }

        System.out.println("Доступные врачи:");
        for (int i = 0; i < doctors.size(); i++) {
            System.out.println((i + 1) + ". " + doctors.get(i));
        }
        System.out.print("Выберите врача: ");
        int docChoice = readInt();
        if (docChoice < 1 || docChoice > doctors.size()) {
            System.out.println("Неверный выбор.");
            return;
        }
        Doctor doctor = doctors.get(docChoice - 1);
        int doctorId = doctor.getId();

        // 2. Ввод даты
        System.out.print("Введите дату приёма (формат: 2025-12-15): ");
        String dateStr = scanner.nextLine().trim();
        LocalDate date;
        try {
            date = LocalDate.parse(dateStr);
        } catch (Exception e) {
            System.out.println("Неверный формат даты.");
            return;
        }

        // 3. Получаем свободные слоты
        List<LocalTime> slots = facade.getAvailableSlots(doctorId, date);
        if (slots.isEmpty()) {
            System.out.println("В этот день нет доступных слотов (выходной или всё занято).");
            return;
        }

        System.out.println("Свободные слоты:");
        for (int i = 0; i < slots.size(); i++) {
            System.out.println((i + 1) + ". " + slots.get(i));
        }

        System.out.print("Выберите слот: ");
        int slotChoice = readInt();
        if (slotChoice < 1 || slotChoice > slots.size()) {
            System.out.println("Неверный выбор слота.");
            return;
        }

        LocalTime chosenTime = slots.get(slotChoice - 1);

        // 4. Пытаемся забронировать
        boolean ok = facade.bookAppointmentInSlot(patientId, doctorId, date, chosenTime);
        if (ok) {
            System.out.println("Запись успешно создана: " + date + " " + chosenTime);
        } else {
            System.out.println("Не удалось создать запись (возможно, слот уже занят).");
        }
    }

    private static void showAppointmentsForPatient(ClinicFacade facade, int patientId) {
        System.out.println("\n=== Мои записи ===");
        List<Appointment> list = facade.getAppointmentsForPatient(patientId);
        if (list.isEmpty()) {
            System.out.println("У вас нет записей.");
            return;
        }
        for (Appointment a : list) {
            System.out.println(a);
        }
    }

    private static void cancelAppointmentAsPatient(ClinicFacade facade, int patientId) {
        System.out.println("\n=== Отмена записи ===");
        List<Appointment> list = facade.getAppointmentsForPatient(patientId);
        if (list.isEmpty()) {
            System.out.println("У вас нет записей.");
            return;
        }

        System.out.println("Ваши записи:");
        for (Appointment a : list) {
            System.out.println(a.getId() + ": " + a);
        }

        System.out.print("Введите ID записи, которую хотите отменить: ");
        int appId = readInt();

        facade.cancelAppointment(appId); // тут внутри работает State
        System.out.println("Если статус позволял, запись была переведена в CANCELLED.");
    }

    // ==================== МЕНЮ ДОКТОРА ====================

    private static void doctorMenu(ClinicFacade facade) {
        System.out.println("\n=== Вход доктора ===");
        int doctorId;
        while (true) {
            System.out.print("Введите ваш doctorId (или 0 для регистрации): ");
            doctorId = readInt();

            if (doctorId == 0) {
                System.out.print("Введите ваше имя: ");
                String name = scanner.nextLine();
                System.out.print("Введите специализацию (например, therapist или surgeon): ");
                String specialization = scanner.nextLine().trim();
                doctorId = facade.addDoctor(name, specialization);
                if (doctorId > 0) {
                    System.out.println("Доктор зарегистрирован. Ваш doctorId = " + doctorId);
                    break;
                } else {
                    System.out.println("Не удалось зарегистрировать доктора. Попробуйте снова.");
                    continue;
                }
            }

            if (facade.doctorExists(doctorId)) {
                break;
            }

            System.out.println("Доктор с таким ID не найден. Попробуйте снова или введите 0 для регистрации.");
        }

        while (true) {
            System.out.println("\n=== Меню доктора ===");
            System.out.println("1. Посмотреть мои записи");
            System.out.println("2. Отметить приём как завершённый");
            System.out.println("0. Назад");
            System.out.print("Ваш выбор: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    showAppointmentsForDoctor(facade, doctorId);
                    break;
                case "2":
                    completeAppointmentAsDoctor(facade, doctorId);
                    break;
                case "0":
                    return;
                default:
                    System.out.println("Неверный выбор.");
            }
        }
    }

    private static void showAppointmentsForDoctor(ClinicFacade facade, int doctorId) {
        System.out.println("\n=== Записи доктора ===");
        List<Appointment> list = facade.getAppointmentsForDoctor(doctorId);
        if (list.isEmpty()) {
            System.out.println("У вас пока нет записей.");
            return;
        }
        for (Appointment a : list) {
            System.out.println(a);
        }
    }

    private static void completeAppointmentAsDoctor(ClinicFacade facade, int doctorId) {
        System.out.println("\n=== Завершение приёма ===");
        List<Appointment> list = facade.getAppointmentsForDoctor(doctorId);
        if (list.isEmpty()) {
            System.out.println("У вас нет записей.");
            return;
        }

        System.out.println("Ваши записи:");
        for (Appointment a : list) {
            System.out.println(a.getId() + ": " + a);
        }

        System.out.print("Введите ID записи, которую хотите завершить: ");
        int appId = readInt();

        facade.completeAppointment(appId); // тут тоже работает State
        System.out.println("Если статус был CONFIRMED, запись стала COMPLETED.");
    }

    // ==================== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ====================

    private static int readInt() {
        while (true) {
            String line = scanner.nextLine();
            try {
                return Integer.parseInt(line.trim());
            } catch (NumberFormatException e) {
                System.out.print("Введите число: ");
            }
        }
    }

    // Однократная инициализация врачей, если таблица пустая
    private static void seedDoctorsIfNeeded(ClinicFacade facade) {
        // простой способ: смотрим, есть ли хоть одна специализация
        List<String> specs = facade.getAllSpecializations();
        if (!specs.isEmpty()) {
            return; // врачи уже есть
        }

        System.out.println("Инициализация тестовых врачей...");
        facade.addDoctor("Иванов Иван", "therapist");
        facade.addDoctor("Петров Пётр", "surgeon");
        System.out.println("Добавлены врачи-тестовые данные.");
    }
}
