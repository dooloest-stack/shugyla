package org.example;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalTime;

public class DoctorFactory {

    // Factory Method: создаёт нужный подкласс Doctor на основе specialization из БД
    public static Doctor fromResultSet(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        String name = rs.getString("name");
        String specialization = rs.getString("specialization");

        String workStartStr = rs.getString("work_start");   // "09:00"
        String workEndStr   = rs.getString("work_end");     // "17:00"
        int slotMinutes     = rs.getInt("slot_minutes");    // 30

        LocalTime workStart = LocalTime.parse(workStartStr);
        LocalTime workEnd   = LocalTime.parse(workEndStr);

        if (specialization == null) {
            throw new IllegalArgumentException("Specialization is null for doctor id=" + id);
        }

        switch (specialization.toLowerCase()) {
            case "therapist":
                return new TherapistDoctor(id, name, workStart, workEnd, slotMinutes);
            case "surgeon":
                return new SurgeonDoctor(id, name, workStart, workEnd, slotMinutes);
            default:
                throw new IllegalArgumentException("Unknown specialization: " + specialization);
        }
    }
}