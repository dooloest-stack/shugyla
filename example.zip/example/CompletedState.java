package org.example;

public class CompletedState implements AppointmentState {

    @Override
    public void confirm(Appointment appointment) {
        System.out.println("Приём уже завершён — подтверждение невозможно.");
    }

    @Override
    public void cancel(Appointment appointment) {
        System.out.println("Нельзя отменить завершённый приём.");
    }

    @Override
    public void complete(Appointment appointment) {
        // уже завершён
    }

    @Override
    public String getName() {
        return "COMPLETED";
    }
}