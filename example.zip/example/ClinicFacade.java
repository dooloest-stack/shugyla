package org.example;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class ClinicFacade {

    private final DoctorRepository doctorRepo = new DoctorRepository();
    private final PatientRepository patientRepo = new PatientRepository();
    private final AppointmentRepository appointmentRepo = new AppointmentRepository();

    private static final LocalTime WORK_START = LocalTime.of(9, 0);
    private static final LocalTime WORK_END = LocalTime.of(17, 0);
    private static final int SLOT_MINUTES = 30;

    // Регистрация пациента
    public int registerPatient(String name, String phone) {
        return patientRepo.addPatient(name, phone);
    }

    // Получить всех врачей по специализации
    public List<Doctor> getDoctorsBySpecialization(String specialization) {
        return doctorRepo.findBySpecialization(specialization);
    }

    // (потом можно добавить getAllSpecializations)
    public List<String> getAllSpecializations() {
        return doctorRepo.getAllSpecializations();
    }

    public boolean patientExists(int patientId) {
        return patientRepo.exists(patientId);
    }

    // Записать пациента к врачу
    public boolean bookAppointment(int patientId, int doctorId, String dateTime) {
        // здесь позже подключим Factory и State
        return appointmentRepo.book(doctorId, patientId, dateTime);
    }

    // Посмотреть записи пациента
    public List<Appointment> getAppointmentsForPatient(int patientId) {
        return appointmentRepo.getForPatient(patientId);
    }

    // Посмотреть записи врача
    public List<Appointment> getAppointmentsForDoctor(int doctorId) {
        return appointmentRepo.getForDoctor(doctorId);
    }

    public void cancelAppointment(int appointmentId) {
        Appointment a = appointmentRepo.getById(appointmentId);
        if (a == null) {
            System.out.println("Запись не найдена.");
            return;
        }

        a.cancel(); // Паттерн State выполняет переход состояния
        appointmentRepo.updateStatus(appointmentId, a.getStatus());
    }

    public void completeAppointment(int appointmentId) {
        Appointment a = appointmentRepo.getById(appointmentId);
        if (a == null) {
            System.out.println("Запись не найдена.");
            return;
        }

        a.complete(); // State
        appointmentRepo.updateStatus(appointmentId, a.getStatus());
    }

    public boolean doctorExists(int doctorId) {
        return doctorRepo.exists(doctorId);
    }

    public int addDoctor(String name, String specialization) {
        return doctorRepo.addDoctor(name, specialization);
    }

    public List<LocalTime> getAvailableSlots(int doctorId, LocalDate date) {

        // 1. Если выходной — возвращаем пустой список
        DayOfWeek day = date.getDayOfWeek();
        if (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) {
            return new ArrayList<>();
        }

        // 2. Получаем врача (чтобы знать его расписание)
        Doctor doctor = doctorRepo.getById(doctorId);

        LocalTime workStart = doctor.getWorkStart();
        LocalTime workEnd = doctor.getWorkEnd();
        int slotMinutes = doctor.getSlotMinutes();

        // 3. Получаем уже занятые записи врача на выбранную дату
        List<Appointment> booked = appointmentRepo.getForDoctorOnDate(doctorId, date);

        List<LocalTime> bookedTimes = new ArrayList<>();
        for (Appointment a : booked) {
            // освобождаем слот, если запись уже отменена или завершена
            String status = a.getStatus();
            if ("CANCELLED".equals(status) || "COMPLETED".equals(status)) {
                continue;
            }
            bookedTimes.add(a.getDateTime().toLocalTime());
        }

        // 4. Генерируем рабочие слоты врача
        List<LocalTime> available = new ArrayList<>();

        LocalTime time = workStart;

        while (time.isBefore(workEnd)) {
            // если слот НЕ занят — добавляем
            if (!bookedTimes.contains(time)) {
                available.add(time);
            }

            time = time.plusMinutes(slotMinutes); // переход к следующему слоту
        }

        return available;
    }

    public boolean bookAppointmentInSlot(int patientId,
                                         int doctorId,
                                         LocalDate date,
                                         LocalTime time) {
        LocalDateTime dateTime = LocalDateTime.of(date, time);
        // статус пока всегда CONFIRMED, как и раньше
        return appointmentRepo.book(doctorId, patientId, dateTime.toString());
    }
}
